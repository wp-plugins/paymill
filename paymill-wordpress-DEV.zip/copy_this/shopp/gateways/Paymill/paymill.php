<?php
/**
 * Paymill
 * @class PaymillShopp
 *
 * @author Matthias Reuter
 * @version 1.2
 * @copyright Matthias Reuter, GPL licensed
 * @package shopp
 * @since 1.2
 * @subpackage PaymillShopp
 **/

require_once(PAYMILL_DIR.'lib/integration/shopplugin.inc.php');

?>