<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
// -----------------------------------------------------------------------require_once(PAYMILL_DIR.'lib/integration/magicmembers.inc.php');

// end file