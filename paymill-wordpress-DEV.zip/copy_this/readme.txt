Some eCommerce Suites don't allow hooking directly to their code.

In this cases you need to copy the appropriate files to your eCommerce suite.

Please take care for directory hierarchy.

If you update your eCommerce suite and Paymill is no longer working, please recheck wether your copied files still exists.